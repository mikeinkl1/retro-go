#ifndef _CONFIG_H_
#define _CONFIG_H_

// Screen
#define TFT_LED_PIN  14
#define TFT_DC_PIN   21 
#define TFT_CS_PIN   05 
#define TFT_MOSI_PIN 23 
#define TFT_CLK_PIN  18 
#define TFT_RST_PIN  21 
#define TFT_MISO_PIN 19

// SD card
#define TFCARD_CS_PIN 22

// Buttons
#define BTN_A        0
#define BTN_B        1
#define BTN_C        2
#define BUTTON_A     0
#define BUTTON_B     1
#define BUTTON_C     2
#define BUTTON_A_PIN 39
#define BUTTON_B_PIN 32
#define BUTTON_C_PIN 33

#define RG_GPIO_GAMEPAD_X           ADC1_CHANNEL_6
#define RG_GPIO_GAMEPAD_Y           ADC1_CHANNEL_7
#define RG_GPIO_GAMEPAD_SELECT      GPIO_NUM_27
#define RG_GPIO_GAMEPAD_START       GPIO_NUM_39
#define RG_GPIO_GAMEPAD_A           GPIO_NUM_32
#define RG_GPIO_GAMEPAD_B           GPIO_NUM_33

// BEEP PIN
#define SPEAKER_PIN      26
#define TONE_PIN_CHANNEL 0


// UART
#define USE_SERIAL Serial

#endif /* SETTINGS_C */
