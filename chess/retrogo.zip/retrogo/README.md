# Description

Retro-Go's shared library (or framework) provides an easy way to port emulators to the ODROID-GO and the ESP32 in general.


# Credits

## Retro-Go
- Alex Duchesne (ducalex)

## Go-Play
- crashoverride / hardkernel

## lodepng
- Lode Vandevenne (lvandeve)

## printf
- Marco Paland (mpaland)

# License
Zlib
